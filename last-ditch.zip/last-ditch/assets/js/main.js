$(document).ready(function(){

  let user_info = 'controllers/user_info.html';
  let contact_info = "controllers/contact_info.html";
  let panic_button = "controllers/panic_button.html";
  let thank_you = "controllers/thank_you.html";

       $('.one').hide().fadeIn("slow");
       $('.two').hide().fadeIn(3000);
       $('.container-fluid').hide().fadeIn('slow');

  //      $('#setup').click(function() {
  //
  //       // window.location= user_info;
  //       $().attr('href', user_info);
  // });


});
